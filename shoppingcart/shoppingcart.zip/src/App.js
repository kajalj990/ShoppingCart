import React, { Component } from 'react';

import './App.css';
import { BrowserRouter as Router } from 'react-router-dom';
import Route from 'react-router-dom/Route';

import Navbar from './components/Navbar';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
class App extends Component {
  render() {
    return (
      <Router>
        <div>
         <Navbar />

        <Route path="/home" component={Home}></Route>
        <Route path="/cart" render={
          () => {
            return (<h1>You chose <span>Cart</span></h1>);
          }
        }></Route>
        <Route path="/login" component={Login }></Route>
        <Route path="/signup" component={Register }></Route>

        </div>
      </Router >
    )
  }
}

export default App

