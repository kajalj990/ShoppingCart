import React, { Component } from 'react'
import { register } from './UserActions'

class Register extends Component {
    constructor() {
        super()
        this.state = {
            name: '',
            gender: '',
            address: '',
            phoneNo: '',
            emailId: '',
            password: '',
            userType: 'customer',
            errors: {}
        }

        this.onChange = this.onChange.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
    }

    onChange(e) {
        
        this.setState({ [e.target.name]: e.target.value })
    }
    onSubmit(e) {
        e.preventDefault()

        const newUser = {
            name: this.state.name,
            gender: this.state.gender,
            address: this.state.address,
            phoneNo: this.state.phoneNo,
            emailId: this.state.emailId,
            password: this.state.password,
            userType: this.state.userType
        }
        console.log(newUser)
        register(newUser).then(res => {
          this.props.history.push(`/login`)
        })
    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-6 mt-5 mx-auto">
                        <form onSubmit={this.onSubmit}>
                            <h1 className="h3 mb-3 font-weight-normal">Register</h1>
                            <div className="form-group">
                                <label htmlFor="name">Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="name"
                                    placeholder="Enter your name"
                                    value={this.state.name}
                                    onChange={this.onChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="gender">Gender</label>
                                <div className="form-check">
                                    <input required className="form-check-input" type="radio" name="gender" id="inlineRadiom" value="m" checked={this.state.gender === "m"} onChange={this.onChange} />
                                    <label className="form-check-label" htmlFor="inlineRadiom">Male</label>
                                </div>
                                <div className="form-check">
                                    <input required className="form-check-input" type="radio" name="gender" id="inlineRadiom" value="f" checked={this.state.gender === "f"} onChange={this.onChange} />
                                    <label className="form-check-label" htmlFor="inlineRadiom">female</label>
                                </div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="address">Address</label>
                                <textarea required
                                    className="form-control"
                                    name="address"
                                    placeholder="Enter address"
                                    value={this.state.address}
                                    onChange={this.onChange} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="phoneNo">Mobile No</label>
                                <input type="number"
                                    className="form-control"
                                    name="phoneNo" maxLength="8"
                                    placeholder="Enter mobileNo"
                                    value={this.state.phoneNo} 
                                    onChange={this.onChange}
                                /></div>
                            <div className="form-group">
                                <label htmlFor="email">Email Id</label>
                                <input required
                                    type="email"
                                    className="form-control"
                                    name="emailId"
                                    placeholder="Enter email"
                                    value={this.state.emailId}
                                    onChange={this.onChange}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="password">Password</label>
                                <input required
                                    type="password"
                                    className="form-control"
                                    name="password"
                                    placeholder="Password"
                                    value={this.state.password}
                                    onChange={this.onChange}
                                />
                            </div>
                            <button
                                type="submit"
                                className="btn btn-lg btn-success btn-block"
                            >
                                Register!
              </button>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

export default Register